Collection of Maven auto-generated reports. The primary interest is probably [Jelly tag libary reference](jelly-taglib-ref.html).
